import base64
from functools import total_ordering
from lib2to3.pgen2 import driver
import os
import re
import time
from collections import deque
from io import BytesIO
from PIL import Image
import cv2
import gym
import numpy as np
from PIL import Image
from gym import spaces
from selenium import webdriver
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from stable_baselines3 import PPO, A2C
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.vec_env import SubprocVecEnv
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import cv2
from collections import namedtuple
import io
from time import sleep
from multiprocessing import Process, Queue
from stable_baselines3.common.vec_env import VecMonitor
import torch


print(torch.cuda.is_available())
print(torch.cuda.device_count())

class EnvironmentChromeTRex(gym.Env):

    def __init__(self,
                 screen_width,  # width of the compressed image
                 screen_height,  # height of the compressed image
                 chromedriver_path: str = 'chromedriver'
                 ):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.chromedriver_path = chromedriver_path
        self.num_observation = 0
        self.score = 0

        self.action_space = spaces.Discrete(4)  # set of actions: do nothing, jump, down
        self.observation_space = spaces.Box(
            low=0,
            high=8192,
            shape=(4, 4),
            dtype=np.uint8
        )
        # connection to chrome
        _chrome_options = webdriver.ChromeOptions()
        _chrome_options.add_argument("--mute-audio")
        _chrome_options.add_argument("disable-infobars")
        _chrome_options.add_argument("window-size=600,900")
        #_chrome_options.add_argument("--headless")
        #_chrome_options.add_argument("--disable-gpu") # if running on Windows

        self._driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=_chrome_options)

        self.current_key = None
        # current state represented by 4 images
        self.state_queue = deque(maxlen=4)

        self.actions_map = [
            Keys.ARROW_UP,  # up
            Keys.ARROW_DOWN,  # down
            Keys.ARROW_LEFT,
            Keys.ARROW_RIGHT
        ]
        action_chains = ActionChains(self._driver)
        self.keydown_actions = [action_chains.key_down(item) for item in self.actions_map]
        self.keyup_actions = [action_chains.key_up(item) for item in self.actions_map]

    def reset(self):
        try:
            self._driver.get('http://www.oispakaljaa.com/')
        except WebDriverException as e:
            print(e)

        self._driver.find_element(By.TAG_NAME, "body") \
            .send_keys(Keys.SPACE)


        WebDriverWait(self._driver, 10).until(
            EC.presence_of_element_located((
                By.CLASS_NAME,
                "katkoviesti"
            ))
        )

        # trigger game start
        self._driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ARROW_DOWN)

        return self._next_observation()

    def _next_observation(self):
        grid2 = np.zeros((4,4))
        grid = [[0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]]
        parent = self._driver.find_element(By.XPATH, '/html/body/div[2]/div[2]/div[6]')
        children = parent.find_elements(By.XPATH, "*")
        for child in children:
            try:
                info = child.get_attribute("class")
                grid2[int(info[28])-1][int(info[26])-1] = child.text
            except:
                pass

        """for row in grid2:
            print(row)"""
            #for printing grid for debug

        return grid2

    def _get_score(self):
        try:
            num = int(''.join(self._driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div/div[1]').text))
        except:
            num = 0
        return num

    def _get_done(self):
        text = ''
        try:
            text = self._driver.find_element(By.XPATH, '/html/body/div[2]/div[2]/div[4]/p').text
        except:
             pass
        if len(text) > 2:
            return True
        else:
            return False
        return self._driver.execute_script("return Runner.instance_.crashed")

    def step(self, action: int):
        self._driver.find_element(By.TAG_NAME, "body") \
            .send_keys(self.actions_map[action])

        obs = self._next_observation()

        done = self._get_done()
        if done:
            reward = -1
        else:
            reward = 0.05
        try:
            num = int(''.join(self._driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div/div[1]/div').text))
        except:
            num = 0
        reward += 0.1*num
        '''try:
            num = int(''.join(self._driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div/div[1]/div').text))
        except:
            num = 0
        score = self._get_score()
        reward = num*0.2
        if reward < 0:
            reward = 0
        if done:
            reward = -180'''
        time.sleep(.015)

        return obs, reward, done, {"score": self._get_score()}


    def close(self):
        if self.viewer is not None:
            self.viewer.close()
            self.viewer = None


import imageio

from tqdm import tqdm
models_dir = "models/PPO"

if not os.path.exists(models_dir):
    os.makedirs(models_dir)
if __name__ == '__main__':
    dir = "models/PPO"
    dir_path = f"{dir}/19000.zip"
    env_lambda = lambda: EnvironmentChromeTRex(
        screen_width=16,
        screen_height=1,
        chromedriver_path=os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "chromedriver"
        )
    )
    do_train = True
    num_cpu = 8
    env = VecMonitor(SubprocVecEnv([env_lambda for i in range(num_cpu)]))

    if do_train:
        checkpoint_callback = CheckpointCallback(
            save_freq= 50000,
            save_path=dir
        )
        model = PPO(
            policy="MlpPolicy",
            env = env,
            verbose=1,
            tensorboard_log="./logs/",
            n_epochs=12,
            n_steps=512
        )
        model.learn(
            total_timesteps=300000,           callback=[checkpoint_callback], log_interval=1
        )
        model.save(f"{models_dir}/{300001}")
        '''TIMESTEPS = 500
        iters = 0
        for i in range(1,10):
            model.learn(total_timesteps=TIMESTEPS, reset_num_timesteps=False, callback=[checkpoint_callback], tb_log_name='PPO')
            model.save(f"{models_dir}/{TIMESTEPS*i*num_cpu}")'''
    #model.save(f"{models_dir}/{num_cpu}")
    #model = PPO.load(f'{models_dir}/{num_cpu}.zip', env=env)
    exit()